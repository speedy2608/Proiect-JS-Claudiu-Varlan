var secretMessage = "From a custom module";
module.exports.msg = secretMessage;